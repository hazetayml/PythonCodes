'''
# importing all required libraries
import telebot
from telethon.sync import TelegramClient
from telethon.tl.types import InputPeerUser, InputPeerChannel
from telethon import TelegramClient, sync, events


# get your api_id, api_hash, token
# from telegram as described above
api_id = '19244222'
api_hash = 'ca59ac88a8b6a24c88ab5863d1c92011'
token = 'AAFgvw35ooe3tpt4QhQ4y0rVFGcTWEgH0Tc'
message = "Working..."

# your phone number
phone = '+6590609803'
'''
import time
import requests
import json
'''
def telegram_bot_sendtext(bot_message):

   bot_token = '5211349802:AAFgvw35ooe3tpt4QhQ4y0rVFGcTWEgH0Tc'
   #chatID obtained from https://api.telegram.org/bot5211349802:AAFgvw35ooe3tpt4QhQ4y0rVFGcTWEgH0Tc/getUpdates
   #https://api.telegram.org/<bot_token>/getUpdates
   bot_chatID = '-790526098'

   send_text = 'https://api.telegram.org/bot' + bot_token + '/sendMessage?chat_id=' + bot_chatID + '&parse_mode=Markdown&text=' + bot_message

   response = requests.get(send_text)

   return response.json()


test = telegram_bot_sendtext("Testing Telegram bot")
print(test)
'''
'''
def send_telegram_message(message):
    """Sends message via Telegram"""
    url = "https://api.telegram.org/" + "5211349802:AAFgvw35ooe3tpt4QhQ4y0rVFGcTWEgH0Tc" + "/sendMessage"
    data = {
        "chat_id": '-790526098',
        "text": message
    }
    try:
        response = requests.request(
            "POST",
            url,
            params=data
        )
        print("This is the Telegram URL")
        print(url)
        print("This is the Telegram response")
        print(response.text)
        telegram_data = json.loads(response.text)
        return telegram_data["ok"]
    except Exception as e:
        print("An error occurred in sending the alert message via Telegram")
        print(e)
        return False
'''
def send_telegram_message(bot_message):

   bot_token = '5211349802:AAFgvw35ooe3tpt4QhQ4y0rVFGcTWEgH0Tc'
   #chatID obtained from https://api.telegram.org/bot5211349802:AAFgvw35ooe3tpt4QhQ4y0rVFGcTWEgH0Tc/getUpdates
   #https://api.telegram.org/<bot_token>/getUpdates
   bot_chatID = '-790526098'

   send_text = 'https://api.telegram.org/bot' + bot_token + '/sendMessage?chat_id=' + bot_chatID + '&parse_mode=Markdown&text=' + bot_message

   response = requests.get(send_text)

   return response.json()

while True:
    # Step 1
    #sensor_value = get_sensor_value_from_pin("A0")
    sensor_value = float(input("Enter value:"))

    print("The current sensor value is:", sensor_value)
    
    # Step 2
    if sensor_value == -999:
        print("Request was unsuccessfull. Skipping.")
        
        time.sleep(10)
        continue
    
    # Step 3
    if sensor_value >= 10: #threshold =10
        print("Sensor value has exceeded threshold")
        message = "Alert! Sensor value has exceeded " + str(10) + \
                  ". The current value is " + str(sensor_value)
        telegram_status = send_telegram_message(message)
        print("This is the Telegram status:", telegram_status)

    # Step 4
    time.sleep(10)

