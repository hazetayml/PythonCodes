Author: Tay Mei Lan, 29 Mar 2022

Sending message to Telegram group if value fails
---------------------------------------------------------------
1. Code: py-telegram-mqtt.py
2. Setup:
<Ref: https://www.hackster.io/akhilsingh0603/send-message-to-telegram-user-using-python-1ce705>
a. Create a bot in telegram :
First of all, create a bot using Telegram BotFather. To create a BotFather follow the below steps –

Open the telegram app and search for @BotFather.
Click on the start button or send “/start”.
Then send “/newbot” message to set up a name and a username (eg. rpmqtt_bot)
After setting name and username BotFather will give you an API token which is your bot token.

b. Obtain the botid 
Botid: 111111xx:Advtdtwcdtycdtqqveuqgye (from Step a above)

c. Create a telegram group (eg. mqtt_group) 
a. Add members to the group
b. Add in the newly created bot.eg. rpmqtt_bot so that the mqtt_bot can send message in the group (use @rpmqtt_bot to find the bot to add), (also can click on mqtt_group profile icon to add members)

d. To obtain chat id
<Ref: https://stackoverflow.com/questions/32423837/telegram-bot-how-to-get-a-group-chat-id>
In the group, send a message from the group to the bot: /my_id @rpmqtt_bot
Open a browser to access: https://api.telegram.org/<bot_token>/getUpdates 
-> A JSON message will be returned
-> Use a online JSON parser http://json.parser.online.fr/
-> Chat id can be found in <message><chat>id field
-> Chatid of group is preceded by negative sign, eg. -112233322

3. Replace botid and chatid in the sample code and proceed with the logic in Python to call the function send_telegram_message(bot_message) to send message when needed.


